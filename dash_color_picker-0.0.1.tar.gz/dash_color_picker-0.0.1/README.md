React-color in Dash Original component: https://casesandberg.github.io/react-color/
